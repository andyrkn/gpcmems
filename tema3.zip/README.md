# gpcmems
main code idea refactored from https://gitlab.com/eugennc/cg/tree/master/homeworks/javascript
# motivation
gpc homeworks
# run
tsc --watch 
